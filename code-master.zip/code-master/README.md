``` 
├─algorithms 算法
│
├─database 数据库    
│
├─distributed 分布式
│
├─java-advance 高级类库和jsr规范等  
│
├─java-basic Java基础 
│
├─mvc mvc框架  
│
├─orm orm框架  
│
├─spring-annotation spring注解驱动开发	
│
├─springboot-aop springaop使用以及aop应用     
│
└─springboot-integration-examples spring以及springboot的demo
 
```

