package main

import "fmt"

func mySqrt(x int) int {


	return 0
}

func main()  {
	fmt.Println(mySqrt(4))
	fmt.Println(mySqrt(8))
}

