package cn.lastwhisper.leetcode.greedy.无重叠区间_435_中等;

class Solution1 {
    /**
     * 题目地址：https://leetcode-cn.com/problems/non-overlapping-intervals/
     * -------------------------------------------------------------------
     * 思考：
     * -------------------------------------------------------------------
     * 思路：
     * -------------------------------------------------------------------
     * 时间复杂度：
     * 空间复杂度：
     */
    public int eraseOverlapIntervals(int[][] intervals) {

        return 0;
    }

    public static void main(String[] args) {

    }
}