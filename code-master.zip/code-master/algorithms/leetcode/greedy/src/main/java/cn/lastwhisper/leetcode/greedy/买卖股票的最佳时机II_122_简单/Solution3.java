package cn.lastwhisper.leetcode.greedy.买卖股票的最佳时机II_122_简单;

class Solution3 {
    /**
     * 题目地址：https://leetcode-cn.com/problems/best-time-to-buy-and-sell-stock-ii/
     * -------------------------------------------------------------------
     * 思考：
     * -------------------------------------------------------------------
     * 思路：动态规划
     *
     * -------------------------------------------------------------------
     * 时间复杂度：
     * 空间复杂度：
     */
    public int maxProfit(int[] prices) {

        return 0;
    }

    public static void main(String[] args) {
        //int[] prices = {7, 1, 5, 3, 6, 4};
        int[] prices = {1, 2, 3, 4, 5};
        System.err.println(new Solution3().maxProfit(prices));
    }
}