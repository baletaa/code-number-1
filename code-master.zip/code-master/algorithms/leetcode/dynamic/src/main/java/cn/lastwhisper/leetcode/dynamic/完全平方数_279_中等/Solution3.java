package cn.lastwhisper.leetcode.dynamic.完全平方数_279_中等;

class Solution3 {
    /**
     * 题目地址：https://leetcode-cn.com/problems/perfect-squares/
     * -------------------------------------------------------------------
     * 思考：
     * -------------------------------------------------------------------
     * 思路：01背包
     * -------------------------------------------------------------------
     * 时间复杂度：O(n)
     * 空间复杂度：O(1)
     */
    public int numSquares(int n) {

        return 3;
    }

    public static void main(String[] args) {
        System.out.println(new Solution3().numSquares(12));
        System.out.println(new Solution3().numSquares(13));
    }
}