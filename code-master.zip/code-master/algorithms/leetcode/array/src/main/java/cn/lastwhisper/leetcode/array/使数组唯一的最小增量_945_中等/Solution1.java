package cn.lastwhisper.leetcode.array.使数组唯一的最小增量_945_中等;

import org.junit.Assert;

class Solution1 {
    /**
     * 题目地址：https://leetcode-cn.com/problems/minimum-increment-to-make-array-unique/
     * -------------------------------------------------------------------
     * 思考：
     * -------------------------------------------------------------------
     * 思路：
     * -------------------------------------------------------------------
     * 时间复杂度：
     * 空间复杂度：
     */
    public int minIncrementForUnique(int[] A) {

        return 0;
    }

    public static void main(String[] args) {
        Assert.assertEquals(6, new Solution1().minIncrementForUnique(new int[]{3, 2, 1, 2, 1, 7}));
    }

}