package cn.lastwhisper.leetcode.week.one175.推文计数_5334_中等;

import java.util.List;

class TweetCounts {

    public TweetCounts() {

    }

    /**
     * 记录推文发布情况：用户 tweetName 在 time（以 秒 为单位）时刻发布了一条推文
     *
     * @param tweetName 用户
     * @param time 时刻
     */
    public void recordTweet(String tweetName, int time) {

    }
    
    /** 
     *
     * @param freq 分 minute，时 hour 或者 日 day 之一
     * @param tweetName 指定用户 tweetName
     * @param startTime 开始时间 startTime（以 秒 为单位）
     * @param endTime 结束时间 endTime（以 秒 为单位）
     */
    public List<Integer> getTweetCountsPerFrequency(String freq, String tweetName, int startTime, int endTime) {

        return null;
    }
    
}

/**
 * Your TweetCounts object will be instantiated and called as such:
 * TweetCounts obj = new TweetCounts();
 * obj.recordTweet(tweetName,time);
 * List<Integer> param_2 = obj.getTweetCountsPerFrequency(freq,tweetName,startTime,endTime);
 */