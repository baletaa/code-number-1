package cn.lastwhisper.leetcode.week.one177.验证二叉树_5170_中等;

class Solution {
    public boolean validateBinaryTreeNodes(int n, int[] leftChild, int[] rightChild) {

        return true;
    }

    public static void main(String[] args) {

    }
}