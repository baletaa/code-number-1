package cn.lastwhisper.leetcode.week.one176.最多可以参加的会议数目_5342;

class Solution {

    public int maxEvents(int[][] events) {
        return 0;
    }
    
    public static void main(String[] args){

    }
}