package cn.lastwhisper.leetcode.week.one177.最接近的因数_5171_中等;

class Solution {
    public int[] closestDivisors(int num) {

        return null;
    }
}