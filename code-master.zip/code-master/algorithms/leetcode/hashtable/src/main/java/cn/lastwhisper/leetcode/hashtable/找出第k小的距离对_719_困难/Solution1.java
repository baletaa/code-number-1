package cn.lastwhisper.leetcode.hashtable.找出第k小的距离对_719_困难;

class Solution1 {
    /**
     * 题目地址：https://leetcode-cn.com/problems/find-k-th-smallest-pair-distance/
     * -------------------------------------------------------------------
     * 思考：
     * 数据特征：
     *     输入：
     *     输出：
     * -------------------------------------------------------------------
     * 思路：
     * -------------------------------------------------------------------
     * 时间复杂度：
     * 空间复杂度：
     */
    public int smallestDistancePair(int[] nums, int k) {

        return 0;
    }
}